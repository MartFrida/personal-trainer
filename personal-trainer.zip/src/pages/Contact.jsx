export const Contact = () => {
  return (
    <div>Contact
      <p>tel +34 697869949, pachamamatw@gmail.com</p>

    </div>
  )
}